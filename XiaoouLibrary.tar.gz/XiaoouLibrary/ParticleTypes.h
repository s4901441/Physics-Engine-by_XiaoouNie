#ifndef PARTICLETYPES_H_
#define PARTICLETYPES_H_

enum class ParticleType
{
  SPHERE,

  TORUS,
  CUBE,
  PLANE
};

#endif // PARTICLETYPEINFO_H

