#include "Cloth_object.h"
#include"Cloth_Particle.h"
#include <ngl/ShaderLib.h>
#include <ngl/VAOFactory.h>
#include <ngl/SimpleVAO.h>
#include <ngl/SimpleIndexVAO.h>
#include <ngl/VAOPrimitives.h>

Cloth_object::Cloth_object(const std::string &_shaderName)
{

/*MouseGlobalTX =_parent->getGlobalTransform();
VPMatrix = _parent->getCamera()->getVPMatrix();
ViewMatrix = _parent->getCamera()->getViewMatrix();*/
m_width = 10;
m_height = 10;
width_num = 5;
height_num = 5;
distance_x = 1;
distance_y = 1;
m_particles.resize(width_num*height_num);
verts.resize(width_num*height_num);
m_shaderName = _shaderName;
m_numParticles = 0;
ngl::Vec3 gravity(0,-9.8f,0);
//insert particles to cloth
for (unsigned int y = 0; y<height_num;y++)
{
  for (unsigned int x = 0; x<width_num;x++)
  {
   ngl::Vec3 position(m_width*((float)x/(float)width_num),m_height*((float)y/(float)height_num),0.0f);
   Cloth_Particle particle_temp = Cloth_Particle(position, ngl::Vec3::zero(),gravity, 0.001f, 0.5,0.2f);
   m_particles[width_num*y+x] = particle_temp;
   verts[width_num*y+x]=particle_temp.GetPos();//position stored for drawing
   //std::cout<<m_particles[width_num*y+x].GetPos().m_y;
   m_numParticles += 1;
  }
}

//std::cout<<m_particles.size();
//work out the indices for drawing


GLushort indices[(width_num-1)*(height_num - 1)*6]; //(width_num-1)*(height_num - 1)*6](width_num*height_num-2)*3there are (n-2)*3 indices , where n is the vertex number
for ( unsigned int y = 0; y<height_num-1;++y)
{
  for (unsigned int x = 0; x<width_num-1;++x)//loop through all polygons in the cloth
  {
    unsigned int offset = (6*(width_num*y+x));
    //std::cout<<offset;
    indices[offset] = (x+y*width_num);        //x,y
    indices[offset+1] = (x+1+y*width_num);      //x+1,y
    indices[offset+2] = (x+(y+1)*width_num);    //x,y+1
    indices[offset+3] = (x+(y+1)*width_num);    //x,y+1
    indices[offset+4] =  (x+1+y*width_num);        //x+1,y
    indices[offset+5] = (x+1+(y+1)*width_num);  //x+1,y+1

 /* std::cout<<indices[offset];
  std::cout<<indices[offset+1];
  std::cout<<indices[offset+2];
  std::cout<<indices[offset+3];
  std::cout<<indices[offset+4];
  std::cout<<indices[offset+5];*/
    //std::cout<<(width_num-1)*(height_num - 1)*6;
  }
}
unsigned int total_num = (width_num-1)*(height_num - 1)*6;
m_vao.reset(ngl::VAOFactory::createVAO("simpleIndexVAO",GL_TRIANGLES) );
m_vao->bind();
m_vao->setData(ngl::SimpleIndexVAO::VertexData(width_num*height_num*sizeof(ngl::Vec3), verts[0].m_x, total_num*sizeof(GLushort),&indices[0], GL_UNSIGNED_SHORT,GL_STATIC_DRAW));
m_vao->setVertexAttributePointer(0,3,GL_FLOAT,0,false);
m_vao->setNumIndices(total_num);
m_vao->unbind();

}

void Cloth_object::Calculate_Cloth_Normal()
{
  for (unsigned int y = 0; y<height_num-1;y++)
  {
    for (unsigned int x = 0; x<width_num-1;x++)
    {
    ngl::Vec3 normal_1 =Calc_Triangle_Normal( getParticle(x+1, y)->GetPos(), getParticle(x,y)->GetPos(), getParticle(x, y+1)->GetPos());
    getParticle(x+1,y)->addNormal(normal_1);
    getParticle(x,y)->addNormal(normal_1);
    getParticle(x,y+1)->addNormal(normal_1);
    ngl::Vec3 normal =Calc_Triangle_Normal( getParticle(x+1, y+1)->GetPos(), getParticle(x+1,y)->GetPos(), getParticle(x, y+1)->GetPos());
    getParticle(x+1,y+1)->addNormal(normal);
    getParticle(x+1,y)->addNormal(normal);
    getParticle(x,y+1)->addNormal(normal);
    }
  }
}


void Cloth_object::draw()
{

 /* unsigned int indices[(width_num*height_num-2)*3]; //there are (n-2)*3 indices , where n is the vertex number
  for ( unsigned int y = 0; y<height_num-1;y++)
  {
    for (unsigned int x = 0; x<width_num-1;x++)
    {
      unsigned int offset = (6*(width_num*y+x));
      //std::cout<<offset;
      indices[offset] =( x+1+y*width_num);        //x+1,y
      indices[offset+1] = x+y*width_num;        //x,y
      indices[offset+2] = x+(y+1)*width_num;    //x,y+1
      indices[offset+3] = x+1+(y+1)*width_num;  //x+1,y+1
      indices[offset+4] = x+1+y*width_num;      //x+1,y
      indices[offset+5] = x+(y+1)*width_num;    //x,y+1

    }

  }
  m_vao.reset(ngl::VAOFactory::createVAO("simpleIndexVAO",GL_TRIANGLES) );
  m_vao->bind();
  m_vao->setData(ngl::SimpleIndexVAO::VertexData( width_num*height_num*sizeof (ngl::Vec3), verts[0].m_x, sizeof(indices),&indices[0], GL_UNSIGNED_BYTE,GL_STATIC_DRAW));
  m_vao->setVertexAttributePointer(0,3,GL_FLOAT,0,0);
  m_vao->setNumIndices(sizeof (indices));
  m_vao->unbind();*/
  ngl::ShaderLib *shader=ngl::ShaderLib::instance();
  (*shader)[m_shaderName]->use();
 // shader->setUniform("Colour",Cd);
  ngl::Transformation t;
  //t.setPosition(P);
  t.setPosition(0,0,0);
  //t.addPosition(0,-10,0);
  ngl::Mat4 MV;
  ngl::Mat4 MVP;
  ngl::Mat3 normalMatrix;
  ngl::Mat4 M;
  M = MouseGlobalTX* t.getMatrix();
  MV= ViewMatrix*M;
  MVP= VPMatrix *  M;
  normalMatrix=MV;
  normalMatrix.inverse().transpose();
  shader->setUniform("MV",MV);
  shader->setUniform("MVP",MVP);
  shader->setUniform("normalMatrix",normalMatrix);
  shader->setUniform("M",M);
  m_vao->bind();
  m_vao->draw();
  m_vao->unbind();


}


Cloth_Particle* Cloth_object::getParticle(unsigned int _x, unsigned int _y)
{
  Cloth_Particle* particle = &m_particles[_y*width_num+_x];
  return particle;
}

ngl::Vec3 Cloth_object::Calc_Triangle_Normal(ngl::Vec3 p1, ngl::Vec3 p2, ngl::Vec3 p3)
{
  ngl::Vec3 normal = (p2 - p1).cross(p3- p1);
  normal.normalize();
  return normal;

}

