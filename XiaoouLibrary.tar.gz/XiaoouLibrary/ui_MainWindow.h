/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *line;
    QLabel *label;
    QLineEdit *lineEdit;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_4;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QComboBox *selectobject;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *lineEdit_2;
    QLabel *label_2;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_4;
    QMenuBar *menubar;
    QMenu *menuMain_Window;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1175, 686);
        MainWindow->setMouseTracking(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        line = new QFrame(centralwidget);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(290, 20, 20, 601));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 200, 111, 21));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(150, 260, 91, 28));
        checkBox_2 = new QCheckBox(centralwidget);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        checkBox_2->setEnabled(true);
        checkBox_2->setGeometry(QRect(30, 300, 161, 31));
        checkBox_2->setChecked(true);
        checkBox_4 = new QCheckBox(centralwidget);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));
        checkBox_4->setGeometry(QRect(30, 160, 171, 31));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 520, 241, 31));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));

        horizontalLayout->addWidget(pushButton);

        selectobject = new QComboBox(centralwidget);
        selectobject->setObjectName(QStringLiteral("selectobject"));
        selectobject->setGeometry(QRect(30, 100, 191, 31));
        horizontalLayoutWidget = new QWidget(centralwidget);
        horizontalLayoutWidget->setObjectName(QStringLiteral("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(330, 20, 821, 601));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit_2 = new QLineEdit(centralwidget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(180, 360, 71, 29));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 340, 161, 61));
        lineEdit_3 = new QLineEdit(centralwidget);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(180, 410, 71, 29));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(30, 410, 141, 31));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 260, 67, 21));
        lineEdit_4 = new QLineEdit(centralwidget);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(150, 200, 113, 29));
        MainWindow->setCentralWidget(centralwidget);
        layoutWidget->raise();
        line->raise();
        label->raise();
        lineEdit->raise();
        checkBox_2->raise();
        checkBox_4->raise();
        selectobject->raise();
        horizontalLayoutWidget->raise();
        lineEdit_2->raise();
        label_2->raise();
        lineEdit_3->raise();
        label_3->raise();
        label_4->raise();
        lineEdit_4->raise();
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1175, 26));
        menuMain_Window = new QMenu(menubar);
        menuMain_Window->setObjectName(QStringLiteral("menuMain_Window"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuMain_Window->menuAction());

        retranslateUi(MainWindow);
        QObject::connect(pushButton_2, SIGNAL(clicked()), MainWindow, SLOT(StartSimulate()));
        QObject::connect(selectobject, SIGNAL(currentIndexChanged(int)), MainWindow, SLOT(Choose_ParticleType()));
        QObject::connect(lineEdit, SIGNAL(editingFinished()), MainWindow, SLOT(Set_Gravity()));
        QObject::connect(lineEdit, SIGNAL(editingFinished()), MainWindow, SLOT(Gravity_change_flag()));
        QObject::connect(checkBox_2, SIGNAL(stateChanged(int)), MainWindow, SLOT(Add_GroundPlane()));
        QObject::connect(pushButton, SIGNAL(clicked()), MainWindow, SLOT(Reset()));
        QObject::connect(lineEdit_4, SIGNAL(editingFinished()), MainWindow, SLOT(Set_Particle_Count()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Particle Count", Q_NULLPTR));
        lineEdit->setText(QApplication::translate("MainWindow", "-9.8", Q_NULLPTR));
        checkBox_2->setText(QApplication::translate("MainWindow", "Ground Plane", Q_NULLPTR));
        checkBox_4->setText(QApplication::translate("MainWindow", "Cloth Simulation", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "Simulate", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Reset", Q_NULLPTR));
        selectobject->clear();
        selectobject->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Sphere", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Cube", Q_NULLPTR)
        );
        label_2->setText(QApplication::translate("MainWindow", "Friction Coefficient", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Bouncing Coefficient", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Gravity", Q_NULLPTR));
        lineEdit_4->setText(QApplication::translate("MainWindow", "100", Q_NULLPTR));
        menuMain_Window->setTitle(QApplication::translate("MainWindow", "RigidBody", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
