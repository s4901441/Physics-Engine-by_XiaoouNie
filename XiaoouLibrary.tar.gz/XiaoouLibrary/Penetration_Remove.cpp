#include "Emitter.h"
#include "IntersectingData.h"
#include <cmath>
void Emitter::Penetration_Remove(std::unique_ptr<Particles> *_this,std::unique_ptr<Particles> *other, IntersectingData _temp)
{
  ngl::Vec3 contactNormal = _temp.GetDirection();//this is contact normal
  ngl::Vec3 invert_dir = -1*contactNormal;
  invert_dir.normalize();
  contactNormal.normalize();

  float penetration_distance = _temp.GetDistance();
/*   if ((*_this)->getType()==ParticleType::SPHERE && (*other)->getType()==ParticleType::SPHERE)
   {
     (*_this)->setPenetration_distance((0.5f*penetration_distance)*invert_dir);
     (*other)->setPenetration_distance((0.5f*penetration_distance)*contactNormal);

   }*/

if((*_this)->getType()==ParticleType::PLANE &&(*other)->getType()==ParticleType::SPHERE) //sphere_plane,only move the sphere
{
  (*other)->setPenetration_distance(penetration_distance*contactNormal);
}
if((*_this)->getType()==ParticleType::PLANE &&(*other)->getType()==ParticleType::CUBE) //sphere_plane,only move the sphere
{
  (*other)->setP(round(penetration_distance)*contactNormal);
}
}
