#include "Emitter.h"
#include "IntersectingData.h"
#include <cmath>
void Emitter::CollisionResponse(std::unique_ptr<Particles> *_this,std::unique_ptr<Particles> *other,IntersectingData _temp)
{
  ngl::Vec3 contactNormal = _temp.GetDirection();//this is contact normal
    ngl::Vec3 invert_dir = -1*contactNormal;
   contactNormal.normalize();
   invert_dir.normalize();
  //invert_dir.normalize();
 //ngl::Vec3 anotherdir =contactNormal.reflect((*_this)->Getv());
 //anotherdir.normalize();

  //float mass = (*_this)->Getmass();
  float d1 = ((*_this)->GetCurrentMomentum()).dot(invert_dir);
  float j1 =-(1+(*_this)->GetCoefficient())*d1;
  float d2 = ((*other)->Get_total_Momentum()).dot(contactNormal);
  float j2 = (-(1+(*other)->GetCoefficient())*d2);


  if ((*_this)->getType()==ParticleType::SPHERE && (*other)->getType()==ParticleType::SPHERE)//sphere-sphere collision
    {
  /* (*_this)->setv(( (*_this)->Getv()).reflect(anotherdir));
    (*other)->setv(( (*_this)->Getv()).reflect(contactNormal));*/
    (*_this)->set_LinearMomentum(j1*invert_dir);
    (*other)->set_LinearMomentum(j2*contactNormal);
    (*_this)->set_active();
    (*other)->set_active();
   // (*_this)->set_Collision_Flag(true);
  //  (*other)->set_Collision_Flag(true);
   }
  if((*_this)->getType()==ParticleType::PLANE &&(*other)->getType()==ParticleType::SPHERE) //sphere-plane
  {
    //(*other)->setv(((*other)->Getv()).reflect(contactNormal));

  /*  if ((*_this)->Getv().length() < 0.01f)
        {
          (*other)->set_stop();
          (*other)->setv(((*other)->Getv())-((*other)->Getv().dot(contactNormal)*contactNormal));

       }*/

    if((*other)->get_bouncing_count()>7)
    {

      (*other)->set_bouncingClamp(true);
      //j2 = 0;

    }
   //force to stop by reducing linear collision momentum
    if((*other)->get_bouncing_count()>=4&&(*other)->get_bouncing_count()<=7)
    {

      j2*=0.25*(7-(*other)->get_bouncing_count());

    }
    if ((*other)->Get_total_Momentum().length() < 0.01f)
    {
      (*other)->set_stop();
      ngl::Vec3 velocity_sliding = ((*other)->Getv())-((*other)->Getv().dot(contactNormal)*contactNormal);
      velocity_sliding.m_y = 0;
      (*other)->setv(velocity_sliding);
    }

    else
    {
      (*other)->set_LinearMomentum(j2*contactNormal);
      (*other)->set_Collision_Flag(true);
      (*other)->increase_bouncing_count();
    }

  }

  if((*_this)->getType()==ParticleType::PLANE &&(*other)->getType()==ParticleType::CUBE) //plane-cube
  {
    if (j2 < 0.2f)
    {
      (*other)->set_stop();
      (*other)->setv(((*other)->Getv())-((*other)->Getv().dot(contactNormal)*contactNormal));

    }

    else
    {
      (*other)->set_LinearMomentum(j2*contactNormal);
    }
  }
  if((*_this)->getType()==ParticleType::CUBE &&(*other)->getType()==ParticleType::CUBE) //plane-cube
  {

    (*_this)->set_LinearMomentum(j1*invert_dir);
    (*other)->set_LinearMomentum(j2*contactNormal);
    (*_this)->set_active();
    (*other)->set_active();
  }
}
