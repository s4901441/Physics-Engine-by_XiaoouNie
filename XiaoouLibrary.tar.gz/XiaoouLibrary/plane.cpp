#include "plane.h"
#include "Emitter.h"
#include "CollidePlane.h"
#include <ngl/ShaderLib.h>
#include <ngl/VAOFactory.h>
#include <ngl/SimpleVAO.h>
#include <ngl/SimpleIndexVAO.h>
#include <ngl/VAOPrimitives.h>

plane::plane(ngl::Vec3 _P, ngl::Vec3 _v, ngl::Vec3 _f, float _mass, const std::string &_shaderName,
          Emitter *_parent,ngl::Colour _c) : Particles (_P,_v,_f,_mass,_shaderName,_parent)
{
    m_distance = 0.0f;
    P = ngl::Vec3(0.0f,m_distance,0.0f);
      v += _v;
      mass = _mass;
      f= _f;
      m_shaderName = _shaderName;
      Cd = _c;
      m_distance = 0;
      linear_momentum = 0;
      friction_coefficient=0.1f;
      m_collider = NULL;
      //set up vertex array for this plane

      verts =
      {
        ngl::Vec3(-100,P.m_y,-100),
        ngl::Vec3(100,P.m_y,-100),
        ngl::Vec3(-100,P.m_y,100),
        ngl::Vec3(100,P.m_y,100)

//        ngl::Vec3(-1,1,-1),
//        ngl::Vec3(1,1,-1),
//        ngl::Vec3(1,1,1),
//        ngl::Vec3(-1,1,1)

       };

//      GLfloat verts[] = {-1,1,-1,
//                              1,1,-1,
//                              1,1,1,
//                              -1,1,1
//                        };

      const static GLbyte indices[] = {
//        0,1,2,3,2,0
        0,1,2,2,1,3

      };
//      ngl::Vec3 n=ngl::calcNormal(verts[2],verts[1],verts[0]);
//      verts.push_back(n);
//      ngl::Vec3 n2=ngl::calcNormal(verts[1],verts[3],verts[2]);
//      verts.push_back(n2);
      m_vao.reset(ngl::VAOFactory::createVAO("simpleIndexVAO",GL_TRIANGLES) );
      m_vao->bind();
      // in this case we are going to set our data as the vertices above
      m_vao->setData(ngl::SimpleIndexVAO::VertexData( 4*sizeof (ngl::Vec3), verts[0].m_x, sizeof(indices),&indices[0], GL_UNSIGNED_BYTE,GL_STATIC_DRAW));
      m_vao->setVertexAttributePointer(0,3,GL_FLOAT,0,0);
//      m_vao->setNumIndices(verts.size());
      m_vao->setNumIndices(sizeof (indices));
      m_vao->unbind();
     /*std::vector<ngl::Vec3> verts=
      {
        ngl::Vec3(0,1,1),
        ngl::Vec3(0,0,-1),
        ngl::Vec3(-0.5,0,1),
        ngl::Vec3(0,1,1),
        ngl::Vec3(0,0,-1),
        ngl::Vec3(0.5,0,1),
        ngl::Vec3(0,1,1),
        ngl::Vec3(0,0,1.5),
        ngl::Vec3(-0.5,0,1),
        ngl::Vec3(0,1,1),
        ngl::Vec3(0,0,1.5),
        ngl::Vec3(0.5,0,1)

      };
      std::cout<<"Initial "<<verts.size()<<'\n';
      ngl::Vec3 n=ngl::calcNormal(verts[2],verts[1],verts[0]);
      verts.push_back(n);
      verts.push_back(n);
      verts.push_back(n);
      n=ngl::calcNormal(verts[3],verts[4],verts[5]);
      verts.push_back(n);
      verts.push_back(n);
      verts.push_back(n);

      n=ngl::calcNormal(verts[6],verts[7],verts[8]);
      verts.push_back(n);
      verts.push_back(n);
      verts.push_back(n);

      n=ngl::calcNormal(verts[11],verts[10],verts[9]);
      verts.push_back(n);
      verts.push_back(n);
      verts.push_back(n);


      std::cout<<"sizeof(verts) "<<sizeof(verts)<<" sizeof(ngl::Vec3) "<<sizeof(ngl::Vec3)<<"\n";
      // create a vao as a series of GL_TRIANGLES
      m_vao.reset(ngl::VAOFactory::createVAO(ngl::simpleVAO,GL_TRIANGLES) );
      m_vao->bind();

      // in this case we are going to set our data as the vertices above
      m_vao->setData(ngl::SimpleVAO::VertexData(verts.size()*sizeof(ngl::Vec3),verts[0].m_x));
      // now we set the attribute pointer to be 0 (as this matches vertIn in our shader)

      m_vao->setVertexAttributePointer(0,3,GL_FLOAT,0,0);

      // now we set the attribute pointer to be 2 (as this matches normal in our shader)
      // as we cast to ngl::Real for offset use 12 * 3 (as in x,y,z is 3 floats)
      m_vao->setVertexAttributePointer(2,3,GL_FLOAT,0,12*3);
      // divide by 2 as we have both verts and normals
      m_vao->setNumIndices(verts.size()/2);

     // now unbind
      m_vao->unbind();
*/
     // m_collider = new CollidePlane(verts[4],0.0f);






//      const static GLubyte indices[]=  {
//                                          0,1,5,0,4,5, // back
//                                          3,2,6,7,6,3, // front
//                                          0,1,2,3,2,0, // top
//                                          4,5,6,7,6,4, // bottom
//                                          0,3,4,4,7,3,
//                                          1,5,2,2,6,5
//                                       };

//       GLfloat vertices[] = {-1,1,-1,
//                             1,1,-1,
//                             1,1,1,
//                             -1,1,1,
//                             -1,-1,-1,
//                             1,-1,-1,
//                             1,-1,1,
//                             -1,-1,1
//                            };

//       GLfloat colours[]={
//                            1,0,0,
//                            0,1,0,
//                            0,0,1,
//                            1,1,1,
//                            0,0,1,
//                            0,1,0,
//                            1,0,0,
//                            1,1,1
//                          };

    //CAREFULL..DON@T USE THE FOLLOWING 2 lines for indexed VAOs
      // in this case we are going to set our data as the vertices above
//       m_vao.reset(ngl::VAOFactory::createVAO(ngl::simpleVAO,GL_TRIANGLES) );
//       m_vao->bind();

//       m_vao.reset( ngl::VAOFactory::createVAO("simpleIndexVAO",GL_TRIANGLES));
//       m_vao->bind();

//       m_vao->setData(ngl::SimpleIndexVAO::VertexData( 24*sizeof(GLfloat),vertices[0],sizeof(indices),&indices[0],GL_UNSIGNED_BYTE,GL_STATIC_DRAW));
//       // now we set the attribute pointer to be 0 (as this matches vertIn in our shader)
//       m_vao->setVertexAttributePointer(0,3,GL_FLOAT,0,0);

//       m_vao->setData(ngl::SimpleIndexVAO::VertexData(24*sizeof(GLfloat),colours[0],sizeof(indices),&indices[0],GL_UNSIGNED_BYTE,GL_STATIC_DRAW));
//       // now we set the attribute pointer to be 0 (as this matches vertIn in our shader)
//       m_vao->setVertexAttributePointer(1,3,GL_FLOAT,0,0);

//       m_vao->setNumIndices(sizeof(indices));
//     // now unbind
//      m_vao->unbind();
}


void plane::draw()const
{
  ngl::ShaderLib *shader=ngl::ShaderLib::instance();
  (*shader)[m_shaderName]->use();
//  shader->setUniform("Colour",Cd);
  ngl::Transformation t;
  //t.setPosition(P);
  t.setPosition(0,0,0);
  //t.addPosition(0,-10,0);
  ngl::Mat4 MV;
  ngl::Mat4 MVP;
  ngl::Mat3 normalMatrix;
  ngl::Mat4 M;
  M=m_parent->getMouseGlobalTX() * t.getMatrix();
  MV= m_parent->getCamera()->getViewMatrix()*M;
  MVP= m_parent->getCamera()->getVPMatrix() *  M;
  normalMatrix=MV;
  normalMatrix.inverse().transpose();
  shader->setUniform("MV",MV);
  shader->setUniform("MVP",MVP);
  shader->setUniform("normalMatrix",normalMatrix);
  shader->setUniform("M",M);
  m_vao->bind();
  m_vao->draw();
  m_vao->unbind();

}
plane::~plane()
{

  if(m_collider!= NULL)
  {
   delete m_collider;
  }
}

void plane::update()
{
  P=P; //do nothing
}

void plane::setCollider()
{
  ngl::Vec3 test_N(0,1,0);
  m_collider = new CollidePlane(test_N,m_distance);
}
