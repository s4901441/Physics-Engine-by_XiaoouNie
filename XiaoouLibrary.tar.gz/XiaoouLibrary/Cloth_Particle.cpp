#include "Cloth_Particle.h"

Cloth_Particle::Cloth_Particle()
{

}

Cloth_Particle::Cloth_Particle(ngl::Vec3 _pos, ngl::Vec3 _v, ngl::Vec3 _f, float _mass, float _sk, float _dk)
{
  m_pos = _pos;
  m_velocity = _v;
  force_total = _f;
  mass = _mass;
  stretching_coefficient = _sk;
  damp_coefficient = _dk;
  TimeInc = 0.02f;
}

void Cloth_Particle::update()
{
  if (is_movable)
  {
  TimeInc = 0.02f;
  ngl::Vec3 acceleration = force_total/mass; //f = ma
  m_velocity += acceleration*TimeInc;//v = v0+at
  m_pos += m_velocity*TimeInc;
  }
}
Cloth_Particle& Cloth_Particle::operator=( Cloth_Particle& particle)
{
  m_pos = particle.GetPos();
  m_velocity = particle.GetVel();
  force_total = particle.Getforce();
  mass = particle.Getmass();
  stretching_coefficient = particle.Get_sk();
  damp_coefficient = particle.Get_dk();
  TimeInc = 0.02f;
  return *this;
}
Cloth_Particle::~Cloth_Particle()
{

}
