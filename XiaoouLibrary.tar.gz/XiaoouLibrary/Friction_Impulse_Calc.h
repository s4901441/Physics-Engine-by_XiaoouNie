#ifndef FRICTION_IMPULSE_CALC_H
#define FRICTION_IMPULSE_CALC_H


class Friction_Impulse_Calc
{
public:
  Friction_Impulse_Calc();
};

#endif // FRICTION_IMPULSE_CALC_H