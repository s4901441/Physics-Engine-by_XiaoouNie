#ifndef TORUS_H
#define TORUS_H
#include "Particles.h"
#include "Collider.h"

class torus : public Particles  //create a chiled class of "Particles" class
{

public:
  torus(ngl::Vec3 _P, ngl::Vec3 _v, ngl::Vec3 _f, float _mass, const std::string &_shaderName,
        Emitter *_parent,ngl::Colour _c);
  virtual ~torus();
  virtual void draw() const;
  virtual void update();
  virtual inline ParticleType getType()const {return m_type;}
  virtual void setCollider(); //get bounding shape & collider type
private :
  /// @brief rotation in the x
  float m_rotX;
  /// @brief x rotation increment value
  float m_rotUpdateX;
  /// @brief rotation in the y
  float m_rotY;
  /// @brief y rotation increment value
  float m_rotUpdateY;
  /// @brief rotation in the z
  float m_rotZ;
  /// @brief z rotation increment value
  float m_rotUpdateZ;
  /// @brief what type of particle this is
  const static ParticleType m_type=ParticleType::TORUS;
  GLfloat m_emitAngle;
  /// @brief the current radius for the sphere
  GLfloat m_radius;
};

#endif // TORUS_H
