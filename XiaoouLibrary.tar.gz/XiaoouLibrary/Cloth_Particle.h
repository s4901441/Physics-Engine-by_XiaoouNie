#ifndef CLOTH_PARTICLE_H
#define CLOTH_PARTICLE_H

#include<ngl/Vec3.h>
class Cloth_Particle
{
private:
  float mass;
  ngl::Vec3 m_pos;
  ngl::Vec3 force_total;
  ngl::Vec3 m_velocity;
  ngl::Vec3 m_normal;
  float stretching_coefficient;
  float damp_coefficient;
  float TimeInc;
public:
  Cloth_Particle();
  Cloth_Particle(ngl::Vec3 _pos, ngl::Vec3 _v, ngl::Vec3 _f, float _mass, float _sk, float _dk);
  ~Cloth_Particle();
  void update();
  inline float Getmass() {return mass;}
  inline float Get_sk() {return stretching_coefficient;}
  inline float Get_dk() {return damp_coefficient;}
  inline ngl::Vec3 GetPos() {return  m_pos;}
  inline ngl::Vec3 GetVel() {return  m_velocity;}
  inline ngl::Vec3 Getforce() {return  force_total;}
  inline void addNormal(ngl::Vec3 _normal) {m_normal += _normal;}
  Cloth_Particle& operator=(Cloth_Particle& particle);
  bool is_movable;
};

#endif // CLOTH_PARTICLE_H
