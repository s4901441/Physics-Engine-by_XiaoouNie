#include "Mainwindow.h"

#include <QtGui/QGuiApplication>
#include "CollidePlane.h"
#include "BoudingSphere.h"
#include "ui_MainWindow.h"
#include <iostream>

int main(int argc, char **argv)
{
  //test
 /* AABB test1(ngl::Vec3 (0.0f,0.0f,0.0f), ngl::Vec3 (1.0f,1.0f,1.0f));
  AABB test2(ngl::Vec3 (1.0f,1.0f,1.0f), ngl::Vec3 (2.0f,2.0f,2.0f));
  AABB test3(ngl::Vec3 (1.0f,0.0f,0.0f), ngl::Vec3 (2.0f,1.0f,1.0f));
  AABB test4(ngl::Vec3 (0.0f,0.0f,-2.0f), ngl::Vec3 (1.0f,1.0f,-1.0f));



  IntersectingData a = test1.IntersectAABB(test2);

  IntersectingData b = test1.IntersectAABB(test3);
  IntersectingData c = test1.IntersectAABB(test4);*/


  QApplication app (argc, argv);
  QSurfaceFormat format;
  format.setSamples(4);

  format.setMajorVersion(4);
  format.setMinorVersion(5);

  format.setProfile(QSurfaceFormat::CoreProfile);
  format.setDepthBufferSize(24);
  QSurfaceFormat::setDefaultFormat(format);



  MainWindow w;
  w.show();

  /*std::cout<<a.CheckIntersect();

  std::cout<<b.CheckIntersect();
  std::cout<<c.CheckIntersect();*/

  //QPushButton button1 ("test");
  //QPushButton button2 ("other", &button1);

  //button1.show();
 /* ngl::Vec3 myvec(0.0f,1.0f,0.0f);
  ngl::Vec3 vec1(0.0f,0.5f,0.0f);
  CollidePlane plane_1(myvec,0.0f);
  BoundingSphere s1(vec1,0.1f);

  IntersectingData test1 = plane_1.PlaneIntersectBoundingSphere(s1);
  std::cout<<test1.CheckIntersect();
  std::cout<<test1.GetDistance();*/


  return app.exec();
}
